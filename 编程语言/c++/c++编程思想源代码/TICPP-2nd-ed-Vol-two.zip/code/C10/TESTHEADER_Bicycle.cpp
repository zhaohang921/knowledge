//: .\C10:TESTHEADER_Bicycle.cpp
//: C10:Bicycle.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Defines classes to build bicycles;
// Illustrates the Builder design pattern.
// Relinquish product
// BICYCLE_H ///:~
#include"Bicycle.h"
int main() {}
